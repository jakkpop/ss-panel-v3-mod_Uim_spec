module.exports = {
  publicPath: '/vuedist/',
  outputDir: '../public/vuedist/'
}
